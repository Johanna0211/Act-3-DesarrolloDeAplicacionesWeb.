<?php
namespace App\Models;
use CodeIgniter\Model;
class HomeModel extends Model 
{
    // Método para obtener la información de pacientes y sus citas
    public function getPacientesYCitas()
    {
        // Construimos la consulta con el query builder de CodeIgniter
        return $this->db->table('Pacientes')
            ->select('
                Pacientes.ID_Paciente,
                Pacientes.Nombre,
                Pacientes.Apellido,
                Pacientes.Fecha_de_nacimiento,
                Pacientes.Telefono,
                Citas.ID_Cita,
                Citas.Fecha,
                Citas.Hora,
                Citas.Motivo
            ')
            ->join('Citas', 'Pacientes.ID_Paciente = Citas.ID_Paciente', 'inner') // Unimos las tablas
            ->get()
            ->getResultArray(); // Retornamos los resultados como arreglo
    }
    // Métodos específicos de obtener la lista de citas
    public function listCitas()
    {
        return $this->db->table('Citas')->get()->getResultArray();
    }
    // Métodos específicos de obtener la lista de Pacientes
    public function listPacientes()
    {
        return $this->db->table('Pacientes')->get()->getResultArray();
    }
}
