<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Define la ruta principal que apunta al método index del controlador Home
$routes->get('/', 'Home::index');
