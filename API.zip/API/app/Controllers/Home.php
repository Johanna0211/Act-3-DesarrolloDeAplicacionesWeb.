<?php
namespace App\Controllers;
use App\Models\HomeModel;
class Home extends BaseController 
{
    protected $homeModel;
    public function __construct()
    {
        $this->homeModel = new HomeModel(); // Inicializamos el modelo
    }
    public function index()
    {
        // Obtiene la lista de Citas
        $citasList = $this->homeModel->listCitas();
        
        // Obtiene la lista de Pacientes
        $pacientesList = $this->homeModel->listPacientes();

        // Consulta para obtener pacientes y citas
        $pacientesYCitas = $this->homeModel->getPacientesYCitas();

        // Prepara un array con los datos para la respuesta
        $responseData = [
            "mensaje" => "Lista de Pacientes y sus Citas en la Clínica Serene", // Mensaje de la primera consulta
            'citas' => $citasList,
            'pacientes' => $pacientesList
        ];

        // Aquí estamos añadiendo la segunda consulta para la respuesta combinada
        $responseData['mensaje_combinado'] = "Información combinada de la Clínica Serene"; // Mensaje para la segunda consulta
        $responseData['pacientes_y_citas'] = $pacientesYCitas;

        // Devuelve los datos en formato JSON
        return $this->response->setJSON($responseData);
    }
}
